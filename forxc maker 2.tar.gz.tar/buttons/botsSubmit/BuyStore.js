const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageAttachment, PermissionsBitField, AttachmentBuilder } = require("discord.js");
const { Database } = require("st.db");
//const { createCanvas, loadImage, registerFont } = require('canvas');
//registerFont('./Bots/store/handlers/DGTrikaRegular.ttf', { family: 'Trika' });
const setting = new Database("/database/settingsdata/setting");
const usersdata = new Database("/database/usersdata/usersdata");
const prices = new Database("/database/settingsdata/prices");
const invoices = new Database("/database/settingsdata/invoices");
const tokens = new Database("/tokens/tokens");
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions");
const offersDB = new Database("/Json-db/Bots/offersDB.json");
const sellersDB = new Database("/Json-db/Bots/sellersDB.json");
const taxDB = new Database("/Json-db/Bots/taxDB.json");
const points = new Database("/Json-db/Bots/pointsDB.json");
const autolineDB = new Database("/Json-db/Bots/autolineDB.json");
const shopDB = new Database("/Json-db/Bots/shopDB.json");
const shortcutDB = new Database("/Json-db/Others/shortcutDB.json");

let store = tokens.get(`store`);
const path = require('path');
const { readdirSync } = require("fs");

module.exports = {
  name: Events.InteractionCreate,
  /**
   * @param {Interaction} interaction
   */
  async execute(interaction) {
    if (interaction.isModalSubmit()) {
      if (interaction.customId == "BuyStore_Modal") {
        await interaction.deferReply({ ephemeral: true });
        let userbalance = parseInt(usersdata.get(`balance_${interaction.user.id}_${interaction.guild.id}`));
        const Bot_token = interaction.fields.getTextInputValue(`Bot_token`);
        const Bot_prefix = interaction.fields.getTextInputValue(`Bot_prefix`);
        const client31 = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember] });

        try {
          const owner = interaction.user.id;
          let price1 = prices.get(`store_price_${interaction.guild.id}`) || 200;
          price1 = parseInt(price1);

          function generateRandomCode() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let code = '';
            for (let i = 0; i < 12; i++) {
              if (i > 0 && i % 4 === 0) {
                code += '-';
              }
              const randomIndex = Math.floor(Math.random() * characters.length);
              code += characters.charAt(randomIndex);
            }
            return code;
          }

          const invoice = generateRandomCode();
          const { REST } = require('@discordjs/rest');
          const rest = new REST({ version: '10' }).setToken(Bot_token);
          const { Routes } = require('discord-api-types/v10');

          client31.on("ready", async () => {
            let doneembeduser = new EmbedBuilder()
              .setTitle(`**تم انشاء بوتك بنجاح**`)
              .setDescription(`**معلومات الفاتورة :**`)
              .addFields(
                {
                  name: `**الفاتورة**`, value: `**\`${invoice}\`**`, inline: false
                },
                {
                  name: `**نوع البوت**`, value: `**\`سيستم ستور\`**`, inline: false
                },
                {
                  name: `**توكن البوت**`, value: `**\`${Bot_token}\`**`, inline: false
                },
                {
                  name: `**البريفكس**`, value: `**\`${Bot_prefix}\`**`, inline: false
                }
              );
            await invoices.set(`${invoice}_${interaction.guild.id}`,
              {
                type: `ستور`,
                token: `${Bot_token}`,
                prefix: `${Bot_prefix}`,
                userid: `${interaction.user.id}`,
                guildid: `${interaction.guild.id}`,
                serverid: `عام`,
                price: price1
              });
            const newbalance = parseInt(userbalance) - parseInt(price1);
            await usersdata.set(`balance_${interaction.user.id}_${interaction.guild.id}`, newbalance);
            const thebut = new ButtonBuilder().setLabel(`دعوة البوت`).setStyle(ButtonStyle.Link).setURL(`https://discord.com/api/oauth2/authorize?client_id=${client31.user.id}&permissions=8&scope=bot%20applications.commands`);
            const rowss = new ActionRowBuilder().addComponents(thebut);
            await interaction.user.send({ embeds: [doneembeduser], components: [rowss] });
          });

          let doneembedprove = new EmbedBuilder()
            .setColor('Aqua')
            .setDescription(`**تم شراء بوت \`ستور\` بواسطة : ${interaction.user}**`)
            .setTimestamp();
          let logroom = setting.get(`log_room_${interaction.guild.id}`);
          let theroom = interaction.guild.channels.cache.find(ch => ch.id == logroom);
          await theroom.send({ embeds: [doneembedprove] });

          // انشاء ايمبد لوج لعملية الشراء و جلب معلومات روم اللوج في السيرفر الرسمي و ارسال الايمبد هناك
          const { WebhookClient } = require('discord.js');
          const { purchaseWebhookUrl } = require('../../config.json');
          const webhookClient = new WebhookClient({ url: purchaseWebhookUrl });
          const theEmbed = new EmbedBuilder()
            .setColor('Green')
            .setTitle('تمت عملية شراء جديدة')
            .addFields(
              { name: `نوع البوت`, value: `\`\`\`ستور\`\`\``, inline: true },
              { name: `سعر البوت`, value: `\`\`\`${price1}\`\`\``, inline: true },
              { name: `المشتري`, value: `\`\`\`${interaction.user.username} , [${interaction.user.id}]\`\`\``, inline: true },
              { name: `السيرفر`, value: `\`\`\`${interaction.guild.name} [${interaction.guild.id}]\`\`\``, inline: true },
              { name: `صاحب السيرفر`, value: `\`\`\`${interaction.guild.ownerId}\`\`\``, inline: true },
              { name: `الفاتورة`, value: `\`\`\`${invoice}\`\`\``, inline: false },
            );
          await webhookClient.send({ embeds: [theEmbed] });

          let userbots = usersdata.get(`bots_${interaction.user.id}_${interaction.guild.id}`);
          if (!userbots) {
            await usersdata.set(`bots_${interaction.user.id}_${interaction.guild.id}`, 1);
          } else {
            userbots = userbots + 1;
            await usersdata.set(`bots_${interaction.user.id}_${interaction.guild.id}`, userbots);
          }
          await interaction.editReply({ content: `**تم انشاء بوتك بنجاح وتم خصم \`${price1}\` من رصيدك**` });

          client31.commands = new Collection();
          client31.events = new Collection();
          require("../../Bots/store/handlers/events")(client31);
          require("../../events/requireBots/store-commands")(client31);
          require("../../Bots/store/handlers/offers")(client31);
          require("../../Bots/store/handlers/tax4bot")(client31);
          require("../../Bots/store/handlers/autorole")(client31);
          require("../../Bots/store/handlers/applyCreate")(client31);
          require("../../Bots/store/handlers/applyResult")(client31);
          require("../../Bots/store/handlers/applySubmit")(client31);
          require("../../Bots/store/handlers/info")(client31);
          require("../../Bots/store/handlers/copy")(client31);
          const folderPath = path.resolve(__dirname, '../../Bots/store/slashcommand31');
          const prefix = Bot_prefix;
          client31.storeSlashCommands = new Collection();
          const storeSlashCommands = [];
          const ascii = require("ascii-table");
          const table = new ascii("store commands").setJustify();
          for (let folder of readdirSync(folderPath).filter(
            (folder) => !folder.includes(".")
          )) {
            for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
              f.endsWith(".js")
            )) {
              let command = require(`${folderPath}/${folder}/${file}`);
              if (command) {
                storeSlashCommands.push(command.data.toJSON());
                client31.storeSlashCommands.set(command.data.name, command);
                if (command.data.name) {
                  table.addRow(`/${command.data.name}`, "🟢 Working");
                } else {
                  table.addRow(`/${command.data.name}`, "🔴 Not Working");
                }
              }
            }
          }

          const folderPath3 = path.resolve(__dirname, '../../Bots/store/handlers');
          for (let file of readdirSync(folderPath3).filter(f => f.endsWith('.js'))) {
            const event = require(path.join(folderPath3, file))(client31);
          }

client31.on("messageCreate", async (message) => {
    if (message.author.bot) return;

    const chanList = await offersDB.get(`offers_room_${message.guild.id}`) || [];
    const roleId = await offersDB.get(`offers_role_${message.guild.id}`);
    const roomLink = await offersDB.get(`offers_roomlink_${message.guild.id}`);
    const offersMode = await offersDB.get(`offers_mode_${message.guild.id}`) || 'link';
    const attachments = message.attachments.map(att => att.url);

    if (chanList.includes(message.channel.id)) {
        const deleteButton = new ButtonBuilder()
            .setCustomId(`deloff_${message.author.id}`)
            .setLabel('Delete Offer')
      //      .setEmoji('🗑️') // إضافة الإيموجي
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder();

        if (offersMode === 'link') {
            const orderButton = new ButtonBuilder()
                .setLabel('Order Now')
                .setURL(roomLink)
                .setStyle(ButtonStyle.Link);
            row.addComponents(orderButton);
        } else if (offersMode === 'custom') {
            const customOrderButton = new ButtonBuilder()
                .setCustomId(`ord_${message.author.id}`)
                .setLabel('Order Now')
         //       .setEmoji('🛒') // إضافة الإيموجي
                .setStyle(ButtonStyle.Success);
            row.addComponents(customOrderButton);
        }

        row.addComponents(deleteButton); 

        const sentMessage = await message.channel.send({
            content: `${message.content}\n\nOffer By: ||<@${message.author.id}>||\nFor: ||<@&${roleId}>||`,
            components: [row],
            files: attachments
        }).catch(console.error);

        const line = await offersDB.get(`line_${message.guild.id}`);
        if (line) {
            await message.channel.send({ files: [line] }).catch(console.error);
        }

        const userPoints = points.get(`points_${message.guild.id}_${message.author.id}`) || 0;
        points.set(`points_${message.guild.id}_${message.author.id}`, userPoints + 1);

        return message.delete();
    }
});


client31.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    
    if (interaction.customId.startsWith('ord_')) {
        const userId = interaction.customId.split('_')[1];
        
        const confirmButton = new ButtonBuilder()
            .setCustomId(`aord_${userId}`)
            .setLabel('تأكيد')
            .setEmoji('✅')
            .setStyle(ButtonStyle.Success);

        const cancelButton = new ButtonBuilder()
            .setCustomId('cord')
            .setLabel('الغاء')
            .setEmoji('❌')
            .setStyle(ButtonStyle.Secondary);
            
        const row = new ActionRowBuilder()
            .addComponents(confirmButton, cancelButton);
            
        await interaction.reply({
            content: 'هل أنت متأكد من فتح تكت لطلب هذا المنتج ؟',
            components: [row],
            ephemeral: true
        });
    }
    
if (interaction.customId === 'cord') {
    await interaction.update({
        content: 'تم الغاء الطلب بنجاح',
        components: [] 
    });
    }
        });


client31.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  const cmd = await shortcutDB.get(`line_cmd_${message.guild.id}`) || null;  
  const line = autolineDB.get(`line_${message.guild.id}`);
  const lineMode = autolineDB.get(`line_mode_${message.guild.id}`) || 'image'; // Default to link if not set

  if (message.content === `${prefix}line` || message.content === `${cmd}`) {
    if (line && message.member.permissions.has('ManageMessages')) {
      await message.delete();
      if (lineMode === 'link') {
        return message.channel.send({ content: `${line}` });
      } else if (lineMode === 'image') {
        return message.channel.send({ files: [line] });
      }
    }
  }
});
  
client31.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const autoChannels = autolineDB.get(`line_channels_${message.guild.id}`);
  if (autoChannels) {
    if (autoChannels.length > 0) {
      if (autoChannels.includes(message.channel.id)) {
        const line = autolineDB.get(`line_${message.guild.id}`);
        const lineMode = autolineDB.get(`line_mode_${message.guild.id}`) || 'image'; // Default to link if not set

        if (line) {
          if (lineMode === 'link') {
            return message.channel.send({ content: `${line}` });
          } else if (lineMode === 'image') {
            return message.channel.send({ files: [line] });
          }
        }
      }
    }
  }
});



client31.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    
    const targetChannelId = offersDB.get(`proof_cha_${message.guild.id}`);
    if (message.channel.id !== targetChannelId) return;

    if (!message.attachments.size) {
        try {
            await message.react("❌");
        } catch {}
        return;
    }

    const messageLink = message.url;
    const linksKey = `user_links_${message.guild.id}_${message.author.id}`;
    
    sellersDB.push(linksKey, messageLink);
    const userPoints = points.get(`points_${message.guild.id}_${message.author.id}`) || 0;
    points.set(`points_${message.guild.id}_${message.author.id}`, userPoints + 1);
    
    try {
        await message.react("✅");
    } catch {}
});

client31.on("interactionCreate" , async(interaction) => {
  if(interaction.isModalSubmit()) {
    if(interaction.customId == "add_goods") {
      let type = interaction.fields.getTextInputValue(`type`)
      let Goods = interaction.fields.getTextInputValue(`Goods`)
      let products = shopDB.get(`products_${interaction.guild.id}`)
      let productFind = products.find(prod => prod.name == type)

      if(!productFind) return interaction.reply({content: `**لا يوجد منتج بهذا الاسم**`})
      let goodsFind = productFind.goods;
      const embed = new EmbedBuilder()
        .setTimestamp(Date.now())
        .setColor('#000000')
      Goods = Goods.split("\n").filter(item => item.trim() !== '')
      productFind.goods = [...goodsFind, ...Goods]
      await shopDB.set(`products_${interaction.guild.id}` , products)
      embed.setTitle(`**[✅] تم اضافة السلع الى المنتج بنجاح**`)
      return interaction.reply({embeds: [embed]})
    }
  } 
})


client31.on('messageCreate', async message => {

    if (!message.content.startsWith(`${prefix}stock`)) return;
    let products = await shopDB.get(`products_${message.guild.id}`);
    if (!products) {
        await shopDB.set(`products_${message.guild.id}`, []);
        products = await shopDB.get(`products_${message.guild.id}`);
    }
    if (!products || products.length <= 0) {
        return message.reply({ content: '**لا يوجد منتجات متوفرة الأن للبيع**' });
    }

    let embed = {
        title: '**جميع المنتجات المتوفرة للبـيع**',
        footer: { text: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) },
        author: { name: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) },
        fields: []
    };

    products.forEach(product => {
        embed.fields.push({
            name: `**\`${product.name}\`**`,
            value: `**> السعر: \`${product.price}\`\n> الكمية المتاحة: \`${product.goods?.length ?? 0}\`\n> للشراء: \`${prefix}buy ${product.name}\`**`,
            inline: false
        });
    });

    await message.channel.send({ embeds: [embed] });
});

client31.on('messageCreate', async message => {
    if (!message.content.startsWith(`${prefix}buy`)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const name = args[1];
    const count = parseInt(args[2], 10) || 1;

    let active = shopDB.get(`active_${message.author.id}`);
    if (active) {
        return message.reply('لديك عملة شراء شغالة بالفعل ، أكملها أولا .');
    }

    if (!count || count <= 0) {
        return message.reply('الرجاء إدخال كمية صحيحة.');
    }

    let products = shopDB.get(`products_${message.guild.id}`);
    let testFind = products.find(ah => ah.name === name);

    let goods = testFind.goods;

    if (!goods || goods.length < count) {
        return message.reply(`**العدد الذي تريد شرائه فوق قدر الكمية الموجودة\nالمتوفر حاليا : ${goods.length}**`);
    }


    let price = parseInt(testFind.price);
    let price1 = price * count;
    let price2 = Math.floor(price1 * (20 / 19) + 1);

    let recipient = shopDB.get(`recipient_${message.guild.id}`);
    let clientrole = shopDB.get(`clientrole_${message.guild.id}`);
    let probot = shopDB.get(`probot_${message.guild.id}`);

    if (!recipient || !clientrole || !probot) {
        return message.reply('**لم يتم إعداد البوت من قبل مالك الخادم. استخدم `/setup` للإعداد.**');
    }

let embed = {
    description: `**قم بتحويل \`${price2}\` إلى <@${recipient}> لإتمام عملية الشراء\n \`\`\`#credit ${recipient} ${price2}\`\`\`لديك 30 ثانية فقط للتحويل**`,
    footer: { 
        text: message.author.username, 
        iconURL: message.author.displayAvatarURL({ dynamic: true }) 
    },
    author: { 
        name: message.guild.name, 
        iconURL: message.guild.iconURL({ dynamic: true }) 
    }
};



    const transfermessage = await message.reply({ embeds: [embed] });
    const message22 = await message.channel.send(`#credit ${recipient} ${price2}`);
    shopDB.set(`active_${message.author.id}`, true);

    const collectorFilter = m => (m.content.includes(price1) && (m.content.includes(recipient) || m.content.includes(`<@${recipient}>`)) && m.author.id == probot);
    const collectorTransfer = message.channel.createMessageCollector({
        filter: collectorFilter,
        max: 1,
        time: 1000 * 30
    });

    collectorTransfer.on('collect', async () => {
        function getRandomAndRemove(array, counter) {
            const result = [];
            for (let i = 0; i < counter; i++) {
                const randomIndex = Math.floor(Math.random() * array.length);
                const randomElement = array.splice(randomIndex, 1)[0];
                result.push(randomElement);
            }
            return result;
        }

        const randomAndRemoved = getRandomAndRemove(goods, count);
        testFind.goods = goods;
        await shopDB.set(`products_${message.guild.id}`, products);

let doneEmbed = {
    title: `**تم الشراء بنجاح!**`,
    description: '**ستصلك المنتجات في الخاص**',
    author: { name: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) }
};

        if (count > 50) {
            // إرسال المنتجات كملف إذا كانت الكمية أكبر من 50
            const fileContent = randomAndRemoved.join('\n');
            const filePath = `./products_${message.author.id}.txt`;
            require('fs').writeFileSync(filePath, fileContent);

            await message.author.send({
                files: [filePath]
            }).then(() => {
                require('fs').unlinkSync(filePath); // حذف الملف بعد الإرسال
            }).catch(() => {
                message.reply('❌ Unable to send the file in DM. Please make sure your DM is open.');
            });
        } else {
            let goodsEmbed = {
                title: `**تم الشراء بنجاح!**`,
                description: `\`\`\`\n${randomAndRemoved.join('\n')}\n\`\`\``,
                author: { name: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) }
            };
      let copybut = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`copynitro`)
          .setLabel('COPY')
          .setStyle(ButtonStyle.Secondary)
      );

await message.author.send({
    embeds: [goodsEmbed],
    components: [copybut]
});
        }

        await message.channel.send({ content: `${message.author}`, embeds: [doneEmbed] });

        if (clientrole) {
            const therole = message.guild.roles.cache.find(ro => ro.id == clientrole);
            if (therole) {
                await message.guild.members.cache.get(message.author.id).roles.add(therole).catch(async () => { return; });
            }
        }
        shopDB.delete(`active_${message.author.id}`);
    });

    collectorTransfer.on('end', async () => {
        try {
            transfermessage.delete().catch(() => { return; });
            await message22.delete().catch(() => { return; });
            shopDB.delete(`active_${message.author.id}`);
        } catch (error) {
            return;
        }
    });
});

/*
client31.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const roleNassabId = "1182797936791388301";
  const roleMawthoqId = "1127332658058367186";

  if (message.content.startsWith("!status")) {
    const args = message.content.split(" ");
    const userId = args[1]?.replace(/[<@!>]/g, "") || message.author.id;

    // جلب معلومات المستخدم المستهدف
    const targetUser = await message.client.users.fetch(userId).catch(() => null);
    if (!targetUser) {
      return message.reply("لم يتم العثور على المستخدم.");
    }

    const starRatings = sellersDB.get(`stars_${message.guild.id}_${userId}`) || [];
    const linksKey = `user_links_${message.guild.id}_${userId}`;
    const links = sellersDB.get(linksKey) || [];
    const totalLinks = links.length;
    const pointsKey = `points_${message.guild.id}_${userId}`;
    const points2 = points.get(pointsKey) || 0; 

    const ratingsCount = [0, 0, 0, 0, 0];
    let totalRating = 0;

    starRatings.forEach(rating => {
      if (rating >= 1 && rating <= 5) {
        ratingsCount[rating - 1] += 1;
        totalRating += rating;
      }
    });

    //const averageRating = (totalRating / starRatings.length).toFixed(2);
let averageRating = starRatings.length > 0 
  ? (Math.round((totalRating / starRatings.length) * 10) / 10).toString() 
  : "0";

  const member = message.guild.members.cache.get(userId);
const roles = member ? member.roles.cache : new Map();

const isNassab = roles.has(roleNassabId);
const isMawthoq = roles.has(roleMawthoqId);



    let statusMessage = "";
    if (isNassab) {
      statusMessage = "نصاب";
    } else if (isMawthoq) {
      statusMessage = "موثوق";
    } else {
      statusMessage = "ليس نصاب ، لكن احذر";
    }

      let description = `
- **النقاط :** ${points2}
- **عدد التقييمات :** ${starRatings.length}
- **عدد دلائل البيع داخل السرفر :** ${totalLinks}
- **الحالة :** ${statusMessage}
`;

    const embed = new EmbedBuilder()
      .setColor("Random")
      .setAuthor({
        name: targetUser.tag,
        iconURL: targetUser.displayAvatarURL({ dynamic: true })
      })
      .setTitle(`${averageRating} / 5 ⭐`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
      .setDescription(description)
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`links_${userId}_${message.guild.id}`)
          .setLabel('دلائل البيع')
          .setStyle('Primary'),
        new ButtonBuilder()
          .setCustomId(`ratings_${userId}_${message.guild.id}`)
          .setLabel('التقييمات')
          .setStyle('Secondary')
      );

    message.reply({ embeds: [embed], components: [row] });
  }
});
*/

client31.on("messageCreate", async (message) => {
const CUSTOM_BACKGROUND = 'https://cdn.akamai.steamstatic.com/steamcommunity/public/images/items/383870/f42a85705dcb548ce6d26dc657630dc72b03d7d0.jpg';
const cmd = await shortcutDB.get(`spro_cmd_${message.guild.id}`) || null;  

  if (message.author.bot) return;
  const roleNassabId = offersDB.get(`nasab_${message.guild.id}`);
  const roleMawthoqId = offersDB.get(`mawtoq_${message.guild.id}`);
  
    if (message.content.startsWith(`${prefix}profile`) || message.content.startsWith(`${cmd}`)) {
    const args = message.content.split(" ");
    const userId = args[1]?.replace(/[<@!>]/g, "") || message.author.id;
    
    const targetUser = await message.client.users.fetch(userId, { force: true }).catch(() => null);
    if (!targetUser) {
      return message.reply("لم يتم العثور على المستخدم.");
    }

    const member = await message.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      return message.reply("لم يتم العثور على العضو في السيرفر.");
    }

    // جلب البيانات
    const starRatings = sellersDB.get(`stars_${message.guild.id}_${userId}`) || [];
    const linksKey = `user_links_${message.guild.id}_${userId}`;
    const links = sellersDB.get(linksKey) || [];
    const totalLinks = links.length;
    const pointsKey = `points_${message.guild.id}_${userId}`;
    const points2 = points.get(pointsKey) || 0;

    let totalRating = 0;
    starRatings.forEach(rating => {
      if (rating >= 1 && rating <= 5) totalRating += rating;
    });
    
    let averageRating = starRatings.length > 0 
      ? (Math.round((totalRating / starRatings.length) * 10) / 10).toString() 
      : "0";

    const roles = member.roles.cache;
    const isNassab = roles.has(roleNassabId);
    const isMawthoq = roles.has(roleMawthoqId);
    
    let statusMessage = "";
    if (isNassab) {
      statusMessage = "نصاب";
    } else if (isMawthoq) {
      statusMessage = "موثوق";
    } else {
      statusMessage = "ليس نصاب ، لكن احذر";
    }

    const canvas = createCanvas(800, 400);
    const ctx = canvas.getContext('2d');

    try {
      // التحقق من وجود بانر للمستخدم
      const userBanner = member.user.bannerURL({ extension: 'png', size: 2048 });
      
      if (userBanner) {
        // استخدام بانر المستخدم إذا كان موجوداً
        const banner = await loadImage(userBanner);
        ctx.drawImage(banner, 0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else {
        // استخدام الخلفية المخصصة إذا لم يكن هناك بانر
        const customBg = await loadImage(CUSTOM_BACKGROUND).catch(() => null);
        
        if (customBg) {
          ctx.drawImage(customBg, 0, 0, canvas.width, canvas.height);
          ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else {
          // استخدام الخلفية المتدرجة كاحتياطي إذا فشل تحميل الخلفية المخصصة
          ctx.fillStyle = isNassab ? 'rgba(0, 0, 0, 1)' :
                         isMawthoq ? 'rgba(255, 215, 0, 0.3)' :
                         'rgba(13, 71, 161, 0.7)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
      }

      // رسم الصورة الشخصية
      const avatar = await loadImage(targetUser.displayAvatarURL({ extension: 'png', size: 256 }));
      
      ctx.save();
      const avatarSize = 100;
      const avatarX = 50;
      const avatarY = 50;
      
      // إطار الصورة الشخصية
      ctx.beginPath();
      ctx.arc(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2 + 5, 0, Math.PI * 2);
      const glowColor = isMawthoq ? '#ffd700' : '#ffffff';
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 15;
      ctx.strokeStyle = glowColor;
      ctx.lineWidth = 3;
      ctx.stroke();

      // الصورة الشخصية
      ctx.beginPath();
      ctx.arc(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
      ctx.restore();

      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 5;

      ctx.font = 'bold 32px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'right';
      ctx.fillText(targetUser.tag, canvas.width - 30, 60);

      const ratingX = canvas.width - 450;
      ctx.fillText(`${averageRating} / 5`, ratingX, 60);
      
      const starX = ratingX + 30;
      const starY = 50;
      const starSize = 20;
      drawStar(ctx, starX, starY, starSize, true);

      ctx.font = '29px Trika';
      ctx.fillText(`النقاط : ${points2}`, 750, 160);
      ctx.fillText(`عدد التقييمات : ${starRatings.length}`, 750, 210);
      ctx.fillText(`عدد دلائل البيع داخل السرفر : ${totalLinks}`, 750, 260);
      ctx.fillText(`الحالة : ${statusMessage}`, 750, 310);

      const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'profile.png' });

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`links_${userId}_${message.guild.id}`)
            .setLabel('دلائل البيع')
            .setStyle('Primary'),
          new ButtonBuilder()
            .setCustomId(`ratings_${userId}_${message.guild.id}`)
            .setLabel('التقييمات')
            .setStyle('Secondary')
        );

      message.reply({ files: [attachment], components: [row] });
      
    } catch (error) {
      console.error('Error creating profile card:', error);
      message.reply('حدث خطأ أثناء إنشاء البطاقة. الرجاء المحاولة مرة أخرى.');
    }
  }
});

function drawStar(ctx, x, y, size, filled = true) {
  ctx.save();
  ctx.beginPath();
  ctx.translate(x, y);
  
  for (let i = 0; i < 5; i++) {
    ctx.lineTo(Math.cos((18 + i * 72) * Math.PI / 180) * size,
               Math.sin((18 + i * 72) * Math.PI / 180) * size);
    ctx.lineTo(Math.cos((54 + i * 72) * Math.PI / 180) * (size / 2),
               Math.sin((54 + i * 72) * Math.PI / 180) * (size / 2));
  }
  
  ctx.closePath();
  if (filled) {
    ctx.fillStyle = '#FFD700';
    ctx.shadowColor = '#FFD700';
    ctx.shadowBlur = 15;
    ctx.fill();
  } else {
    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 2;
    ctx.stroke();
  }
  ctx.restore();
}


client31.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;

  const [action, userId, guildId] = interaction.customId.split('_'); 

if (action === 'links') {
    const linksKey = `user_links_${guildId}_${userId}`;
    const messageLinks = sellersDB.get(linksKey) || [];

    if (messageLinks.length === 0) {
        return interaction.reply({ content: "لا توجد دلائل للبائع.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const files = [];
    for (const link of messageLinks) {
        const matches = link.match(/channels\/\d+\/(\d+)\/(\d+)/);
        if (!matches) continue;
        
        const channelId = matches[1];
        const messageId = matches[2];

        const channel = await interaction.client.channels.fetch(channelId);
        if (!channel) continue;

        const message = await channel.messages.fetch(messageId);
        if (!message || !message.attachments.size) continue;

        message.attachments.forEach((attachment) => {
            files.push({
                attachment: attachment.url,
                name: attachment.name || `image-${files.length + 1}.png`
            });
        });

        if (files.length >= 10) break;
    }

    return interaction.editReply({
        content: "هذه عدة دلائل:",
        files: files,
        ephemeral: true
    });
}
  if (action === 'ratings') {
    const starRatings = sellersDB.get(`messages_${guildId}_${userId}`) || []; 

    if (starRatings.length === 0) {
      return interaction.reply({ content: "لا توجد تقييمات للبائع.", ephemeral: true });
    }
    const limitedRatings = starRatings.slice(0, 20);
    const ratingsMessage = limitedRatings.join("\n");

    return interaction.reply({ content: `هذه عدة تقييمات للبائع :\n${ratingsMessage}`, ephemeral: true });
  }
});


client31.on('messageCreate', async message => {
const cmd = await shortcutDB.get(`come_cmd_${message.guild.id}`) || null;  
    if (message.content.startsWith(`${prefix}come`) || message.content.startsWith(`${cmd}`)) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('يجب أن تملك صلاحية إدارة الرسائل (MANAGE_MESSAGES).');
        }
        const mentionOrID = message.content.split(/\s+/)[1];
        const targetMember = message.mentions.members.first() || message.guild.members.cache.get(mentionOrID);
        if (!targetMember) {
            return message.reply('من فضلك قم بعمل منشن لشخص أو ضع الإيدي.');
        }
        const directMessageContent = `**تم استدعائك بواسطة : ${message.author}\nفي : ${message.channel}**`;
        try {
            await targetMember.send(directMessageContent);
            await message.reply('**تم الارسال للشخص بنجاح**');
        } catch (error) {
            await message.reply('**لم استطع الارسال للشخص**');
        }
    }
});

client31.on('messageCreate', async message => {
const cmd = await shortcutDB.get(`tax_cmd_${message.guild.id}`) || null; 
    if (message.content.startsWith(`${prefix}tax`) || message.content.startsWith(`${cmd}`)) {
        const args = message.content.startsWith(`${prefix}tax`) 
            ? message.content.slice(`${prefix}tax`.length).trim() 
            : message.content.slice(`${cmd}`.length).trim();

        let number = args;
        if (number.endsWith("k")) number = number.replace(/k/gi, "") * 1000;
        else if (number.endsWith("K")) number = number.replace(/K/gi, "") * 1000;
        else if (number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
        else if (number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;

        let number2 = parseFloat(number);

        if (isNaN(number2)) {
            return message.reply('يرجى إدخال رقم صحيح بعد الأمر');
        }

        let tax = Math.floor(number2 * (20) / (19) + 1); // الضريبة
        let tax2 = Math.floor(tax - number2); // المبلغ مع الضريبة

        await message.reply(`${tax}`);
    }
});

client31.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  let roomid = taxDB.get(`tax_room_${message.guild.id}`);
  let taxLine = taxDB.get(`tax_line_${message.guild.id}`);
  let taxMode = taxDB.get(`tax_mode_${message.guild.id}`) || 'embed'; 
  let taxColor = taxDB.get(`tax_color_${message.guild.id}`) || '#0099FF'; 

  if (roomid) {
    if (message.channel.id === roomid) {
      if (message.author.bot) return;

      let number = message.content;

      if (number.endsWith("k")) number = number.replace(/k/gi, "") * 1000;
      else if (number.endsWith("K")) number = number.replace(/K/gi, "") * 1000;
      else if (number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
      else if (number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;

      if (isNaN(number) || number == 0) return message.delete();

      let number2 = parseInt(number); // المبلغ
      let tax = Math.floor(number2 * 20 / 19 + 1); // المبلغ مع الضريبة
      let tax2 = Math.floor(tax - number2); // الضريبة
      let tax3 = Math.floor(tax * 20 / 19 + 1); // المبلغ مع ضريبة الوسيط
      let tax4 = Math.floor(number2 * 0.02); // نسبة الوسيط
      let tax5 = Math.floor(tax3 + tax4); // الضريبة كاملة مع نسبة الوسيط

      let description = `
🪙 المبلغ ** : ${number2}**
- ضريبة برو بوت **: ${tax}**
- المبلغ كامل مع ضريبة الوسيط **: ${tax3}**
- نسبة الوسيط 2 % **: ${tax4}**
- الضريبة كاملة مع نسبة الوسيط **: ${tax5}**
`;

      let btn1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`tax_${tax}`)
          .setLabel('Tax')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(`mediator_${tax5}`)
          .setLabel('Mediator')
          .setStyle(ButtonStyle.Secondary)
      );

      if (taxMode === 'embed') {
        let embed1 = new EmbedBuilder()
          .setColor(taxColor)
          .setDescription(description)
          .setThumbnail(message.guild.iconURL({ dynamic: true }));

        message.reply({ embeds: [embed1], components: [btn1] });

        if (taxLine) {
          message.channel.send({ files: [taxLine] });
        }
      } else {
        message.reply({ content: description, components: [btn1] });

        if (taxLine) {
          message.channel.send({ files: [taxLine] });
        }
      }

      return;
    }
  }
});


client31.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const line = offersDB.get(`line_${message.guild.id}`);
  const chan = offersDB.get(`feedback_room_${message.guild.id}`);
  const feedbackEmoji = offersDB.get(`feedback_emoji_${message.guild.id}`) || "❤"; 

  if (chan) {
    if (message.channel.id !== chan) return;

    await message.react(feedbackEmoji);
    if (line) {
      await message.channel.send({ files: [line] });
    }
  }

  const mention = message.mentions.users.first();
  if (mention) {
    const originalMessage = message.content; 
    const modifiedMessage = `<@${message.author.id}> : ${originalMessage.replace(`<@${mention.id}>`, "").trim()}`;
    sellersDB.push(`messages_${message.guild.id}_${mention.id}`, modifiedMessage);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder().setCustomId("star_1").setEmoji("⭐").setLabel("1").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("star_2").setEmoji("⭐").setLabel("2").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("star_3").setEmoji("⭐").setLabel("3").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("star_4").setEmoji("⭐").setLabel("4").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("star_5").setEmoji("⭐").setLabel("5").setStyle(ButtonStyle.Success)
      );

    const sentMessage = await message.channel.send({
      content: `يرجى تقييم ${mention} من 1 إلى 5 نجوم.`,
      components: [row],
    });

    const filter = (interaction) =>
      interaction.isButton() &&
      interaction.message.id === sentMessage.id &&
      interaction.user.id === message.author.id;

    const collector = sentMessage.createMessageComponentCollector({
      filter,
      time: 60000,
    });

    collector.on("collect", async (interaction) => {
      const rating = parseInt(interaction.customId.split("_")[1]); 
      sellersDB.push(`stars_${message.guild.id}_${mention.id}`, rating);

      const pointsToAdd = rating === 5 ? 3 : rating === 4 ? 1 : rating === 2 ? -1 : rating === 1 ? -3 : 0;

      const pointsKey = `points_${message.guild.id}_${mention.id}`;
      const currentPoints = points.get(pointsKey) || 0;
      const newPoints = Math.max(0, currentPoints + pointsToAdd); 
      points.set(pointsKey, newPoints);

      await interaction.reply({
        content: `تم تسجيل تقييمك: ${rating} نجوم.`,
        ephemeral: true,
      });

      collector.stop();
    });

    collector.on("end", async () => {
      await sentMessage.delete();
    });
  }
});




client31.on('messageCreate', async (message) => {
const parentIds = offersDB.get(`claim_cate_${message.guild.id}`) || [];
const supportId = offersDB.get(`claim_role_${message.guild.id}`);
const cmd = await shortcutDB.get(`claim_cmd_${message.guild.id}`) || null;  
const cmd2 = await shortcutDB.get(`unclaim_cmd_${message.guild.id}`) || null;  

    if (message.author.bot) return;
    if (!parentIds.includes(message.channel.parentId)) return;
    if (message.content.startsWith(`${prefix}claim`) || message.content.startsWith(`${cmd}`)) {
        const channelPermissions = message.channel.permissionOverwrites.cache;
        const hasClaimed = channelPermissions.some(perm => 
            perm.id === message.member.id && 
            perm.allow.has(PermissionsBitField.Flags.SendMessages)
        );

        if (hasClaimed) return; 

        try {
            await message.channel.permissionOverwrites.edit(
                message.guild.roles.cache.find(role => role.id === supportId),
                {
                    ViewChannel: true,
                    SendMessages: false
                }
            );

            await message.channel.permissionOverwrites.edit(message.member, {
                ViewChannel: true,
                SendMessages: true
            });

            const embed = new EmbedBuilder()
                .setColor("Random")
                .setDescription(`✅ لقد قمت باستلام التذكرة بنجاح`);

               await message.reply({ embeds: [embed] });

            const userPoints = points.get(`points_${message.guild.id}_${message.author.id}`) || 0;
            points.set(`points_${message.guild.id}_${message.author.id}`, userPoints + 1);
        } catch (error) {
            console.error('خطأ أثناء استلام التذكرة:', error);
        }
    }

    if (message.content.startsWith(`${prefix}unclaim`) || message.content.startsWith(`${cmd2}`)) {
        const channelPermissions = message.channel.permissionOverwrites.cache;
        const hasClaimed = channelPermissions.some(perm => 
            perm.id === message.member.id && 
            perm.allow.has(PermissionsBitField.Flags.SendMessages)
        );

        if (!hasClaimed) return; 

        try {
            await message.channel.permissionOverwrites.edit(
                message.guild.roles.cache.find(role => role.id === supportId),
                {
                    ViewChannel: true,
                    SendMessages: true
                }
            );
            await message.channel.permissionOverwrites.delete(message.member);
            const embed = new EmbedBuilder()
                .setColor("Random")
                .setDescription(`✅ لقد قمت باستلام التذكرة بنجاح`);

               await message.reply({ embeds: [embed] });
            const userPoints = points.get(`points_${message.guild.id}_${message.author.id}`) || 0;
            if (userPoints > 0) {
                points.set(`points_${message.guild.id}_${message.author.id}`, userPoints - 1);
            }
        } catch (error) {
            console.error('خطأ أثناء إلغاء استلام التذكرة:', error);
        }
    }
});

client31.on("interactionCreate", async (interaction) => {
    if(interaction.customId === "help_settings") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
          .addFields(
            {name : `\`/setup-basics\`` , value : `لتسطيب الأساسيات`},
            {name : `\`/add-claimablecat\`` , value : `اضافة كاتيجوري قابلة للاستلام`},
            {name : `\`/set-shortcut\`` , value : `لانشاء اختصار أمر`},
            {name : `\`/embed\`` , value : `لانشاء امبد`},
            {name : `\`/add-info-button\`` , value : `لاضافة زر معلومات`},
            {name : `\`${prefix}profile\`` ,  value : `لاظهار بروفايل السيلر`},
            {name : `\`${prefix}come\`` ,  value : `لاستدعاء شخص`},
            {name : `\`${prefix}claim\`` ,  value : `لاستلام تكت`},
            {name : `\`${prefix}unclaim\`` ,  value : `لترك التكت`}
          )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️').setDisabled(true),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_offers") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
          .addFields(
              { name: `\`/setup-offers\``, value: `لتسطيب النظام` },
              { name: `\`/set-line\``, value: `لتحديد خط العروض` },
              { name: `\`/set-offers-room\``, value: `اضافة روم للعروض` },
              { name: `\`/remove-offers-room\``, value: `ازالة روم من العروض` },
          )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒').setDisabled(true),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_tax") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
          .addFields(
            {name : `\`/set-tax-room\`` , value : `لتحديد روم الضريبة التلقائية`},
            {name : `\`/set-tax-line\`` , value : `لتحديد الخط`},
            {name : `\`/tax-mode\`` , value : `لتحديد شكل الضريبة`},
            {name : `\`/tax\` | \`${prefix}tax\`` , value : `لحساب ضريبة بروبوت اي مبلغ تريده`}
          )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰').setDisabled(true),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_management") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
      .addFields(
        {name : `\`/setup-apply\`` , value : `لتسطيب نظام التقديم`},
        {name : `\`/new-apply\`` , value : `لانشاء تقديم جديد`},
        {name : `\`/dm-mode\`` , value : `لارسال رسالة لخاص المتقدم عند الرفض او القبول`},
        {name : `\`/close-apply\`` , value : `لانهاء التقديم المفتوح`},
        {name : `\`/set-slogan\`` , value : `لتحديد شعار التقديم`}
      )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝').setDisabled(true),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_autoRanks") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
      .addFields(
        {name : `\`/new-panel\`` , value : `انشاء بنل رتب جديد`},
        {name : `\`/add-button\`` , value : `اضافة زر جديد للرتبة`},
      )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡').setDisabled(true)
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_font") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
      .addFields(
        {name : `\`/set-autoline-line\`` , value : `لتحديد الخط`},
        {name : `\`/add-autoline-channel\`` , value : `لاضافة روم خط تلقائي`},
        {name : `\`/remove-autoline-channel\`` , value : `لازالة روم خط تلقائي`},
        {name : `\`/line-mode\`` , value : `تحديد طريقة ارسال الخط`},
        {name : `\`${prefix}line\`` , value : `لارسال خط`},
      )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖').setDisabled(true),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_stock") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
    .addFields(
      {name : `\`/setup-shop\`` , value : `لتسطيب الاعدادات الرئيسية`},
      {name : `\`/add-product\`` , value : `لاضافة نوع من المنتجات للبيع`},
      {name : `\`/add-product-goods\`` , value : `لاضافة سلع لمنتج معين`},
      {name : `\`/fast-add-product-goods\`` , value : `لاضافة سلع لمنتج معين بشكل أسرع`},
      {name : `\`/edit-product-price\`` , value : `لتعديل سعر منتج`},
      {name : `\`/remove-product\`` , value : `لازالة نوع من المنتجات للبيع`},
      {name : `\`/give\`` , value : `اعطاء منتج`},
      {name : `\`/remove-product-goods\`` , value : `لازالة سلع من منتج معين`},
          {name : `\`${prefix}buy\`` , value : `لشراء سلعة`},
          {name : `\`${prefix}stock\`` , value : `لرؤية المنتجات المتاحة للبيع`},
    )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦').setDisabled(true),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐')
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });

    } else if (interaction.customId === "help_reviews") {
        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('قائمة اوامر البوت')
      .addFields(
        {name : `\`/set-feedback-line\`` , value : `لتحديد خط الاراء`},
        {name : `\`/set-feedback-room\`` , value : `لتحديد روم الاراء`},
      )
            .setTimestamp()
            .setFooter({ text: `Requested By ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setColor('DarkButNotBlack');

       const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_settings').setLabel('الأساسيات').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('help_offers').setLabel('العروض').setStyle(ButtonStyle.Secondary).setEmoji('🛒'),
            new ButtonBuilder().setCustomId('help_tax').setLabel('الضريبة').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
            new ButtonBuilder().setCustomId('help_management').setLabel('تقديم الادارة').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
            new ButtonBuilder().setCustomId('help_autoRanks').setLabel('الرتب التلقائية').setStyle(ButtonStyle.Secondary).setEmoji('⚡')
        );
const btns2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_font').setLabel('الخط').setStyle(ButtonStyle.Secondary).setEmoji('🤖'),
    new ButtonBuilder().setCustomId('help_stock').setLabel('الستوك').setStyle(ButtonStyle.Secondary).setEmoji('📦'),
    new ButtonBuilder().setCustomId('help_reviews').setLabel('التقييم').setStyle(ButtonStyle.Secondary).setEmoji('⭐').setDisabled(true)
);
      await interaction.update({ embeds: [embed], components: [btns, btns2] });
    }
});

          client31.on('ready', async () => {
            setInterval(async () => {
              let BroadcastTokenss = tokens.get(`store`);
              let thiss = BroadcastTokenss.find(br => br.token == Bot_token);
              if (thiss) {
                if (thiss.timeleft <= 0) {
                  console.log(`${client31.user.id} Ended`);
                  await client31.destroy();
                }
              }
            }, 1000);
          });

          client31.on("ready", async () => {
            try {
              await rest.put(
                Routes.applicationCommands(client31.user.id),
                { body: storeSlashCommands },
              );
            } catch (error) {
              console.error(error);
            }
          });

          const folderPath2 = path.resolve(__dirname, '../../Bots/store/events');
          for (let file of readdirSync(folderPath2).filter(f => f.endsWith('.js'))) {
            const event = require(path.join(folderPath2, file));
          }

          client31.on("interactionCreate", async (interaction) => {
            if (interaction.isChatInputCommand()) {
              if (interaction.user.bot) return;

              const command = client31.storeSlashCommands.get(interaction.commandName);

              if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
              }
              if (command.ownersOnly === true) {
                if (owner != interaction.user.id) {
                  return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true });
                }
              }
              if (command.adminsOnly === true) {
                if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                  return interaction.reply({ content: `❗ ***يجب أن تمتلك صلاحية الأدمن لاستخدام هذا الأمر***`, ephemeral: true });
                }
              }
              try {
                await command.execute(interaction);
              } catch (error) {
                console.error(`Error executing ${interaction.commandName}`);
                console.error(error);
              }
            }
          });

          await client31.login(Bot_token).catch(async () => {
            return interaction.editReply({ content: `**فشل التحقق , الرجاء تفعيل اخر ثلاث خيارات في قائمة البوت**` });
          });

          if (!store) {
            await tokens.set(`store`, [{ token: Bot_token, prefix: Bot_prefix, clientId: client31.user.id, owner: interaction.user.id, timeleft: 2629744 }]);
          } else {
            await tokens.push(`store`, { token: Bot_token, prefix: Bot_prefix, clientId: client31.user.id, owner: interaction.user.id, timeleft: 2629744 });
          }

        } catch (error) {
          console.error(error);
          return interaction.editReply({ content: `**قم بتفعيل الخيارات الثلاثة او التاكد من توكن البوت ثم اعد المحاولة**` });
        }
      }
    }
  }
}
