const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const { Database } = require("st.db");

const inviteDB = new Database("/Json-db/Bots/invitesDB.json");

module.exports = {

  ownersOnly: false,

  data: new SlashCommandBuilder()

    .setName('invites')

    .setDescription('عرض عدد الدعوات التي قام بها شخص')

    .addUserOption(option =>

      option.setName('user')

        .setDescription('الشخص المطلوب عرض دعواته')

        .setRequired(true)

    ),

  async execute(interaction, client) {

    await interaction.deferReply({ ephemeral: false });

    const user = interaction.options.getUser('user');

    const guildId = interaction.guild.id;

    // سحب بيانات الدعوات من قاعدة البيانات

    const joined = inviteDB.get(`invites_${guildId}_${user.id}_joined`) || 0;

    const left = inviteDB.get(`invites_${guildId}_${user.id}_left`) || 0;

    const total = joined - left;

    const embed = new EmbedBuilder()

      .setColor("#000000")

      .setTitle(`دعوات ${user.username}`)

      .setDescription(`✅ **${joined} joins** in total

❌ **${left} leaves**

This user has currently **${total}** invites! 👏

**Last members invited by ${user.username}**`)

      .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })

      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });

  }

};

