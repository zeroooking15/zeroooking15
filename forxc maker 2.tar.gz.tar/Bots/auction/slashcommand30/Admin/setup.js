const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const auctionDB = new Database("/Json-db/Bots/auctionDB.json");

const auctions = {};
module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('setup-auction')
        .setDescription('تسطيب نظام المزاد')
        .addChannelOption(option =>
            option
                .setName('room')
                .setDescription('الروم اللي تنرسل لها المزادات')
                .setRequired(true))
        .addRoleOption(option =>
            option
                .setName('role')
                .setDescription('الرتبة الي تقدر تسوي مزاد')
                .setRequired(true)),
    async execute(interaction) {
        try {
            const room = interaction.options.getChannel('room');
            const role = interaction.options.getRole('role');
            await auctionDB.set(`auction_room_${interaction.guild.id}`, room.id);
            await auctionDB.set(`auction_role_${interaction.guild.id}`, role.id);
            return interaction.reply({ content: '**تم تحديد الروم والرتبة بنجاح**' });
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: '**حدث خطأ أثناء تحديد الروم أو الرتبة**', ephemeral: true });
        }
    }
};
