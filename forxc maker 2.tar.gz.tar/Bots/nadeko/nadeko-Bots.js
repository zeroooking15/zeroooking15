
  const { Client, Collection, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, ModalBuilder, TextInputBuilder, TextInputStyle} = require("discord.js");
const { Database } = require("st.db")
const nadekoDB = new Database("/Json-db/Bots/nadekoDB.json")
const tokens = new Database("/tokens/tokens")
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions")


let nadeko = tokens.get('nadeko')
if(!nadeko) return;

const path = require('path');
const { readdirSync } = require("fs");
let theowner;
nadeko.forEach(async(data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix , token , clientId , owner } = data;
  theowner = owner
  const client15 =new Client({intents: 131071, shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
  client15.commands = new Collection();
  require(`./handlers/events`)(client15);
  client15.events = new Collection();
  client15.setMaxListeners(1000)

  require(`../../events/requireBots/nadeko-commands`)(client15);
  const rest = new REST({ version: '10' }).setToken(token);
  client15.on("ready" , async() => {

      try {
        await rest.put(
          Routes.applicationCommands(client15.user.id),
          { body: nadekoSlashCommands },
          );
          
        } catch (error) {
          console.error(error)
        }

    });
        client15.once('ready', () => {
    client15.guilds.cache.forEach(guild => {
        guild.members.fetch().then(members => {
            if (members.size < 10) {
                console.log(`apply bot : Guild: ${guild.name} has less than 10 members`);
            }
        }).catch(console.error);
    });
});
    
  //------------- التحقق من وقت البوت --------------//
  client15.on("ready", async () => {
    setInterval(async () => {
      let BroadcastTokenss = tokens.get(`nadeko`) || [];
      let thiss = BroadcastTokenss.find((br) => br.token == token);
      if (thiss) {
        if (thiss.timeleft <= 0) {
          const user = await client15.users.cache.get(owner) || await client15.users.fetch(owner);
          const embed = new EmbedBuilder()
                    .setDescription(`**مرحبا <@${thiss.owner}>،لقد انتهى اشتراك بوتك <@${thiss.clientId}>. النوع : رومات مؤقت\nالاشتراك انتهى**`)
                    .setColor("DarkerGrey")
                    .setTimestamp();
          await user.send({embeds : [embed]}).catch((err) => {console.log(err)})

          const filtered = BroadcastTokenss.filter((bo) => bo != thiss);
          await tokens.set(`nadeko`, filtered);
          await client15.destroy().then(async () => {
            console.log(`${clientId} Ended`);
          });
        }
      }
    }, 1000);
  });
    require(`../nadeko/handlers/events`)(client15)

  const folderPath = path.join(__dirname, 'slashcommand15');
  client15.nadekoSlashCommands = new Collection();
  const nadekoSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("nadeko commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
    )) {
      for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
      )) {
        let command = require(`${folderPath}/${folder}/${file}`);
        if (command) {
          nadekoSlashCommands.push(command.data.toJSON());
          client15.nadekoSlashCommands.set(command.data.name, command);
          if (command.data.name) {
            table.addRow(`/${command.data.name}`, "🟢 Working");
          } else {
            table.addRow(`/${command.data.name}`, "🔴 Not Working");
          }
        }
  }
}

for (let file of readdirSync('/home/container/Bots/nadeko/slashcommand15').filter(f => f.endsWith('.js'))) {

  const cmd = require(`./slashcommand15/${file}`);

  if (cmd.data) client16.creditSlashCommands.set(cmd.data.name, cmd);

  // تشغيل حدث صوتي لو موجود

  if (cmd.name === Events.VoiceStateUpdate && typeof cmd.executeEvent === "function") {

    client15.on("voiceStateUpdate", (...args) => cmd.executeEvent(...args));
}
    }



const folderPath2 = path.join(__dirname, 'slashcommand15');

for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
  for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
    const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
  }
}

require(`../../events/requireBots/nadeko-commands`)(client15)
require("./handlers/events")(client15)

	for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
		const event = require(`./events/${file}`);
	if (event.once) {
		client15.once(event.name, (...args) => event.execute(...args));
	} else {
		client15.on(event.name, (...args) => event.execute(...args));
	}
	}
client15.on("interactionCreate", async interaction => {

  const voiceDB = new (require("st.db")).Database("/Json-db/Bots/voiceRooms.json");

  const userRoomId = voiceDB.get(`room_${interaction.guild.id}_${interaction.user.id}`);

  const channel = interaction.guild.channels.cache.get(userRoomId);

  if (interaction.isButton()) {

    if (!channel) return;

    if (interaction.customId === "lock_unlock") {

      const isLocked = channel.permissionOverwrites.cache.get(interaction.guild.id)?.deny.has("Connect");

      await channel.permissionOverwrites.edit(interaction.guild.id, {

        Connect: isLocked ? null : false

      });

      await interaction.reply({ content: `تم ${isLocked ? "فتح" : "قفل"} الروم.`, ephemeral: true });

    } else if (interaction.customId === "rename_room") {

      const modal = new ModalBuilder().setCustomId("rename_modal").setTitle("تغيير اسم الروم");

      const nameInput = new TextInputBuilder().setCustomId("new_name").setLabel("الاسم الجديد").setStyle(TextInputStyle.Short).setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(nameInput));

      await interaction.showModal(modal);
} else if (interaction.customId === "transfer_owner") {

      const modal = new ModalBuilder().setCustomId("transfer_modal").setTitle("نقل ملكية الروم");

      const idInput = new TextInputBuilder().setCustomId("new_owner_id").setLabel("أدخل ايدي العضو").setStyle(TextInputStyle.Short).setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(idInput));

      await interaction.showModal(modal);

    } else if (interaction.customId === "delete_room") {

      await channel.delete();

      await voiceDB.delete(`room_${interaction.guild.id}_${interaction.user.id}`);

      await interaction.reply({ content: "تم حذف الروم بنجاح.", ephemeral: true });

    } else if (interaction.customId === "limit_users") {

      const modal = new ModalBuilder().setCustomId("limit_modal").setTitle("تحديد عدد الأعضاء");

      const limitInput = new TextInputBuilder().setCustomId("user_limit").setLabel("عدد الأعضاء المسموح (1-10)").setStyle(TextInputStyle.Short).setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(limitInput));

      await interaction.showModal(modal);

    }

  } else if (interaction.isModalSubmit()) {

    if (!channel) return;
if (interaction.customId === "rename_modal") {

      const newName = interaction.fields.getTextInputValue("new_name");

      await channel.setName(newName);

      await interaction.reply({ content: `تم تغيير الاسم إلى: ${newName}`, ephemeral: true });

    } else if (interaction.customId === "transfer_modal") {

      const newId = interaction.fields.getTextInputValue("new_owner_id");

      const newMember = interaction.guild.members.cache.get(newId);

      if (!newMember) return interaction.reply({ content: "العضو غير موجود", ephemeral: true });

      await channel.permissionOverwrites.edit(newId, { Connect: true, ManageChannels: true });

      await channel.permissionOverwrites.edit(interaction.user.id, { ManageChannels: false });

      await voiceDB.set(`room_${interaction.guild.id}_${newId}`, channel.id);

      await voiceDB.delete(`room_${interaction.guild.id}_${interaction.user.id}`);

      await interaction.reply({ content: `تم نقل الملكية إلى: <@${newId}>`, ephemeral: true });

    } else if (interaction.customId === "limit_modal") {

      const value = parseInt(interaction.fields.getTextInputValue("user_limit"));

      if (isNaN(value) || value < 1 || value > 10) {

        return interaction.reply({ content: "أدخل رقم بين 1 و 10.", ephemeral: true });

      }

      await voiceDB.set(`limit_${interaction.guild.id}_${interaction.user.id}`, value);

      await interaction.reply({ content: `تم تعيين الحد بـ ${value} أشخاص.`, ephemeral: true });

    }

  }

});


client15.on("interactionCreate" , async(interaction) => {
  if(interaction.customId === "help_general"){
    const embed = new EmbedBuilder()
        .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
        .setTitle('قائمة اوامر البوت')
        .setDescription('**لا توجد اوامر في هذا القسم حاليا**')
        .setTimestamp()
        .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
        .setColor('DarkButNotBlack');
    const btns = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐').setDisabled(true),
        new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑'),
    )

    await interaction.update({embeds : [embed] , components : [btns]})
  }else if(interaction.customId === "help_owner"){
    const embed = new EmbedBuilder()
    .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
    .setTitle('قائمة اوامر البوت')
    .addFields(
      {name : `\`/join\`` , value : `ارسال بانل تحكم بل روم`},
        {name : `\`/set-ch\`` , value : `تحديد روم صوت`}
    )
    .setTimestamp()
    .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
    .setColor('DarkButNotBlack');
const btns = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐'),
    new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑').setDisabled(true),
)

await interaction.update({embeds : [embed] , components : [btns]})
  }
})

  client15.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) {
      
	    if(interaction.user.bot) return;

      
      const command = client15.nadekoSlashCommands.get(interaction.commandName);
	    
      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
        }
      }
      try {

        await command.execute(interaction);
      } catch (error) {
			return
		}
    }
  } )



   client15.login(token)
   .catch(async(err) => {
    const filtered = nadeko.filter(bo => bo != data)
			await tokens.set(`nadeko` , filtered)
      console.log(`${clientId} Not working and removed `)
   });


})
