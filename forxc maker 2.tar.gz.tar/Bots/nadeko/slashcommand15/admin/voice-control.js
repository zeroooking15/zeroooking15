const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

const { Database } = require("st.db");

const voiceDB = new Database("/Json-db/Bots/voiceRooms.json");

module.exports = {

  data: new SlashCommandBuilder()

    .setName("voice-control")

    .setDescription("تحكم في الروم الصوتي الخاص بك"),

  async execute(interaction) {

    const userRoomId = voiceDB.get(`room_${interaction.guild.id}_${interaction.user.id}`);

    const channel = interaction.guild.channels.cache.get(userRoomId);

    if (!userRoomId || !channel) {

      return interaction.reply({ content: "لا تملك روم صوتي خاص حالياً.", ephemeral: true });

    }

    const embed = new EmbedBuilder()

      .setTitle("لوحة التحكم في الروم الصوتي")

      .setColor("DarkButNotBlack");

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder().setCustomId("lock_unlock").setLabel("قفل / فتح الروم").setStyle(ButtonStyle.Primary),

      new ButtonBuilder().setCustomId("rename_room").setLabel("تغيير الاسم").setStyle(ButtonStyle.Secondary),

      new ButtonBuilder().setCustomId("transfer_owner").setLabel("نقل الملكية").setStyle(ButtonStyle.Success),

      new ButtonBuilder().setCustomId("delete_room").setLabel("حذف الروم").setStyle(ButtonStyle.Danger),

      new ButtonBuilder().setCustomId("limit_users").setLabel("تحديد عدد الأعضاء").setStyle(ButtonStyle.Secondary)

    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });

  }

};

