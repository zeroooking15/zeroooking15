const { SlashCommandBuilder, ChannelType } = require("discord.js");

const { Database } = require("st.db");

const catalogDB = new Database("/Json-db/Bots/voiceCatalogs.json");

module.exports = {

  data: new SlashCommandBuilder()

    .setName("select-catalog")

    .setDescription("حدد كتالوج لإنشاء الرومات الصوتية بداخله")

    .addChannelOption(option =>

      option.setName("catalog")

        .setDescription("اختر كاتيجوري للرومات الصوتية")

        .setRequired(true)

        .addChannelTypes(ChannelType.GuildCategory)

    ),

  async execute(interaction) {

    const catalog = interaction.options.getChannel("catalog");

    catalogDB.set(`catalog_${interaction.guild.id}_${interaction.user.id}`, catalog.id);

    await interaction.reply({ content: `تم حفظ الكتالوج: ${catalog.name}`, ephemeral: true });

  }

};

