const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const { Database } = require("st.db");

const catalogDB = new Database("/Json-db/Bots/voiceCatalogs.json");

const voiceDB = new Database("/Json-db/Bots/voiceRooms.json");

module.exports = {

  data: new SlashCommandBuilder()

    .setName("create-room")

    .setDescription("ينشئ روم صوتي باسمك في الكتالوج المختار"),

  async execute(interaction) {

    const guild = interaction.guild;

    const user = interaction.user;

    // تحقق هل لديه روم محفوظ

    const existingRoomId = voiceDB.get(`room_${guild.id}_${user.id}`);

    if (existingRoomId) {

      const existingChannel = guild.channels.cache.get(existingRoomId);

      if (existingChannel) {

        return interaction.reply({ content: `لديك بالفعل روم صوتي: ${existingChannel}`, ephemeral: true });

      } else {

        // إذا الروم غير موجود في السيرفر نحذفه من قاعدة البيانات ونكمل الإنشاء

        voiceDB.delete(`room_${guild.id}_${user.id}`);

      }

    }

    const catalogId = catalogDB.get(`catalog_${guild.id}_${user.id}`);

    if (!catalogId) {

      return interaction.reply({ content: "لم تقم بتحديد كتالوج بعد، استخدم أمر `/select-catalog` أولاً.", ephemeral: true });

    }

    const category = guild.channels.cache.get(catalogId);

    if (!category || category.type !== 4) {

      return interaction.reply({ content: "الكاتيجوري المحدد غير موجود أو لم يعد كاتيجوري صالح.", ephemeral: true });

    }

    const channel = await guild.channels.create({

      name: user.username,

      type: 2, // روم صوتي

      parent: category.id,

      permissionOverwrites: [

        {

          id: guild.id,

          deny: [PermissionFlagsBits.Connect]

        },

        {

          id: user.id,

          allow: [

            PermissionFlagsBits.Connect,

            PermissionFlagsBits.Speak,

            PermissionFlagsBits.MuteMembers,

            PermissionFlagsBits.DeafenMembers,

            PermissionFlagsBits.MoveMembers,

            PermissionFlagsBits.ManageChannels

          ]

        }

      ]

    });

    voiceDB.set(`room_${guild.id}_${user.id}`, channel.id);

    await interaction.reply({ content: `تم إنشاء الروم الصوتي الخاص بك: ${channel}`, ephemeral: true });

  }

};

