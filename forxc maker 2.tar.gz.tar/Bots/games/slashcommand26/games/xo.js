const { TicTacToe } = require('discord-gamecord');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('xo')
    .setDescription('play-xo')
    .addUserOption(option => option.setName('user').setDescription('اختر مستخدمًا للعب معه!').setRequired(true)),

    async execute (interaction) {
        const Game = new TicTacToe({
            message: interaction,
            isSlashGame: true,
            opponent: interaction.options.getUser('user'),
            embed: {
                title: 'لعبة Tic Tac Toe!',
                color: '#575757',
                statusTitle: 'الحالة',
                overTitle: 'انتهت اللعبة!'
            },

            emojis: {
                xButton: '✖️',
                oButton: '⭕',
                blankButton: '➖'
            },

            mentionUser: true,
            timeoutTime: 60000,
            xButtonStyle: 'DANGER',
            oButtonStyle: 'PRIMARY',
            turnMessage: "{emoji} | دورك الآن، **{player}**",
            winMessage: "{emoji} | **{player}** فاز في لعبة Tic Tac Toe!",
            tieMessage: 'اللعبة انتهت بالتعادل! لم يفز أحد في لعبة Tic Tac Toe. :(',
            timeoutMessage: 'انتهت اللعبة بسبب عدم النشاط! لم يفز أحد في اللعبة.',
            playerOnlyMessage: 'فقط {player} و {opponent} يمكنهما التفاعل مع اللعبة الحالية!'
        });

        Game.startGame();
        Game.on('gameover', result => {
            return;

        })
    }
}
