
const { Client, Collection,ChannelType ,SlashCommandBuilder, GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder , ButtonStyle , Message, Embed,PermissionsBitField } = require("discord.js")
const { Database } = require("st.db")
const gamesDB = new Database("/Json-db/Bots/gamesDB.json")
const tokens = new Database("/tokens/tokens")
const tier1subscriptions = new Database("/database/makers/tier1/subscriptions")


let moment = require('moment');
const ms = require("ms")
const buyCooldown = new Collection()
let games = tokens.get('games')
if(!games) return;

const path = require('path');
const { readdirSync } = require("fs");
const client = require("../../index.js")
const { connect } = require("http2")
let theowner;
games.forEach(async(data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix , token , clientId , owner } = data;
  theowner = owner
  const client26 = new Client({intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
  client26.commands = new Collection();
  client26.setMaxListeners(1000)
  require(`./handlers/events.js`)(client26);
  client26.events = new Collection();
  require(`../../events/requireBots/games-commands.js`)(client26);
  const rest = new REST({ version: '10' }).setToken(token);
  client26.on("ready" , async() => {

      try {
        await rest.put(
          Routes.applicationCommands(client26.user.id),
          { body: gamesSlashCommands },
          );
          
        } catch (error) {
          console.error(error)
        }

    });
        client26.once('ready', () => {
    client26.guilds.cache.forEach(guild => {
        guild.members.fetch().then(members => {
            if (members.size < 10) {
                console.log(`games bot : Guild: ${guild.name} has less than 10 members`);
            }
        }).catch(console.error);
    });
});
  //------------- التحقق من وقت البوت --------------//
  client26.on("ready", async () => {
    setInterval(async () => {
      let BroadcastTokenss = tokens.get(`games`) || [];
      let thiss = BroadcastTokenss.find((br) => br.token == token);
      if (thiss) {
        if (thiss.timeleft <= 0) {
          const user = await client26.users.cache.get(owner) || await client26.users.fetch(owner);
          const embed = new EmbedBuilder()
                    .setDescription(`**مرحبا <@${thiss.owner}>،لقد انتهى اشتراك بوتك <@${thiss.clientId}>. النوع : العاب\nالاشتراك انتهى**`)
                    .setColor("DarkerGrey")
                    .setTimestamp();
          await user.send({embeds : [embed]}).catch((err) => {console.log(err)})

          const filtered = BroadcastTokenss.filter((bo) => bo != thiss);
          await tokens.set(`games`, filtered);
          await client26.destroy().then(async () => {
            console.log(`${clientId} Ended`);
          });
        }
      }
    }, 1000);
  });
    require(`./handlers/events.js`)(client26)
  const folderPath = path.join(__dirname, 'slashcommand26');
  client26.gamesSlashCommands = new Collection();
  const gamesSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("games commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
    )) {
      for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
      )) {
        let command = require(`${folderPath}/${folder}/${file}`);
        if (command) {
          gamesSlashCommands.push(command.data.toJSON());
          client26.gamesSlashCommands.set(command.data.name, command);
          if (command.data.name) {
            table.addRow(`/${command.data.name}`, "🟢 Working");
          } else {
            table.addRow(`/${command.data.name}`, "🔴 Not Working");
          }
        }
  }
}

let commandsDir2 = path.join(__dirname);
client26.commands = new Collection()
const commands = [];
const table2 = new ascii('Prefix Commands').setJustify();
for (let folder of readdirSync(commandsDir2+`/slashcommand26`).filter(f => f.endsWith(`.js`))) {
	  let command = require(`${commandsDir2}/slashcommand26/${folder}`);
	  if(command) {
		commands.push(command);
  client26.commands.set(command.name, command);
		  if(command.name) {
			  table2.addRow(`${prefix}${command.name}` , '🟢 Working')
		  }
		  if(!command.name) {
			  table2.addRow(`${prefix}${command.name}` , '🔴 Not Working')
		  }
	  }
}


require(`../../events/requireBots/games-commands.js`)(client26)
require("./handlers/events.js")(client26)

	for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
		const event = require(`./events/${file}`);
	if (event.once) {
		client26.once(event.name, (...args) => event.execute(...args));
	} else {
		client26.on(event.name, (...args) => event.execute(...args));
	}
	}

client26.on("messageCreate" , async(message) => {
  if (message.author.bot) return;
  if (message.channel.type === 'dm') return;
  if(!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/g); 
  const cmd = args.shift().toLowerCase();
  if(cmd.length == 0 ) return;
    if(!client26.commands.has(cmd)) return;
  let command = client26.commands.get(cmd)
  if(!command) command = client26.commands.get(client26.commandaliases.get(cmd));

  if(command) {
    if(command.cooldown) {
        
      if(cooldown.has(`${command.name}${message.author.id}`)) return message.reply({ embeds:[{description:`**عليك الانتظار\`${ms(cooldown.get(`${command.name}${message.author.id}`) - Date.now(), {long : true}).replace("minutes", `دقيقة`).replace("seconds", `ثانية`).replace("second", `ثانية`).replace("ms", `ملي ثانية`)}\` لكي تتمكن من استخدام الامر مجددا.**`}]}).then(msg => setTimeout(() => msg.delete(), cooldown.get(`${command.name}${message.author.id}`) - Date.now()))
      command.run(client, message, args)
      cooldown.set(`${command.name}${message.author.id}`, Date.now() + command.cooldown)
      setTimeout(() => {
        cooldown.delete(`${command.name}${message.author.id}`)
      }, command.cooldown);
  } else {
    command.run(client, message, args)
  }
}});

client26.on("messageCreate", async message => {
  const gameRoleID = await gamesDB.get(`games_role_${message.guild.id}`);  

  if (!message.guild || message.author.bot) return;
  if (!gameRoleID) return;
  let args = message.content.split(" ");
  if (args[0] === prefix + "مافيا") {
    if (!message.member.roles.cache.has(gameRoleID)) return;
    require("./handlers/mafia")(message);
  } else if(args[0] === prefix + "روليت") {
    if (!message.member.roles.cache.has(gameRoleID)) return;
    require("./handlers/roulette")(message);
  }
});


  client26.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) {
      
	    if(interaction.user.bot) return;

      
      const command = client26.gamesSlashCommands.get(interaction.commandName);
	    
      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
        }
      }
      try {

        await command.execute(interaction);
      } catch (error) {
			return
		}
    }
  } )

  client26.on("interactionCreate" , async(interaction) => {
    if(interaction.customId === "help_general"){
      const embed = new EmbedBuilder()
          .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
          .setTitle('قائمة اوامر البوت')
          .addFields(
          {name : `\`/games\`` , value : `لاظهار شرح الألعاب`},
          {name : `\`/2048\`` , value : `بدء لعبة 2048`},
          {name : `\`/connect4\`` , value : `بدء لعبة connect4`},
          {name : `\`/matchpairs\`` , value : `بدء لعبة المطابقة`},
          {name : `\`/minesweeper\`` , value : `بدء لعبة كاسحة الألغام`},
          {name : `\`/snake\`` , value : `بدء لعبة الثعبان`},
          {name : `\`/xo\`` , value : `بدء لعبة اكس او`},
          {name : `\`${prefix}مافيا\`` , value : `بدء لعبة المافيا`},
          {name : `\`${prefix}روليت\`` , value : `بدء لعبة الروليت`},
          )
          .setTimestamp()
          .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
          .setColor('DarkButNotBlack');
      const btns = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐').setDisabled(true),
          new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑'),
      )
  
      await interaction.update({embeds : [embed] , components : [btns]})
    }else if(interaction.customId === "help_owner"){
      const embed = new EmbedBuilder()
      .setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL({dynamic : true})})
      .setTitle('قائمة اوامر البوت')
          .addFields(
          {name : `\`/set-games-role\`` , value : `لتحديد مسؤول المافيا و الروليت`},
          )
      .setTimestamp()
      .setFooter({text : `Requested By ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic : true})})
      .setColor('DarkButNotBlack');
  const btns = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('help_general').setLabel('عامة').setStyle(ButtonStyle.Success).setEmoji('🌐'),
      new ButtonBuilder().setCustomId('help_owner').setLabel('اونر').setStyle(ButtonStyle.Primary).setEmoji('👑').setDisabled(true),
  )
  
  await interaction.update({embeds : [embed] , components : [btns]})
    }
  })

  client26.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return; 
  if (message.content === `<@${client26.user.id}>`) {
    return message.reply({
      content: `**Hello In <@${client26.user.id}> , I'm Using / Commands and my prefix is ${prefix}**`,
    });
  }
});

   client26.login(token)
   .catch(async(err) => {
    const filtered = games.filter(bo => bo != data)
			await tokens.set(`games` , filtered)
      console.log(`${clientId} Not working and removed `)
   });


})
